#James Valles
#Homework 3 

install.packages('reshape')
install.packages('ggbeeswarm')
install.packages('ggforce')
library(ggplot2)
library(reshape)
library(magrittr)
library(scales)
library(ggbeeswarm)
library(tidyr)
library(ggforce)

df <- AirQuality
ggplot(df, aes(x=Wind, y=Solar.R)) + geom_violin() + geom_violin(trim=FALSE)+ stat_summary(fun.y=median, geom="point", size=2, color="red") + geom_jitter(shape=16, position=position_jitter(0.2))

pivot <- pivot_longer(df, c(Ozone, Solar.R, Wind, Temp, Month, Day), names_to = "Measurement", values_to = "Value")

pivot %>% 
  ggplot(aes(Measurement, Value)) +
  geom_beeswarm()

pivot %>% 
  ggplot(aes(Measurement, Value)) +
  geom_violin() + geom_sina()

pivot + geom_violin() + geom_sina()


aq %>% ggplot(aes(Wind,Solar.R)) + geom_point()

ggplot(aq, aes(sample=Wind)) +
  geom_qq() +
  geom_qq_line()



qqnorm(df$Solar.R)
qqline(df$Solar.R, col="red")

qqnorm(df$Wind)
qqline(df$Wind, col="red")

qqplot(df$Wind, df$Solar.R)

qqplot(df$Wind, df$Solar.R)
x <- rnorm(1000)
qqnorm(x)
abline(0, 1, col = 'red')

boxplot(df[,1:4]) 
boxplot(df$Solar.R ~ df$Wind) 
