#James Valles - Assignment 2 - RCode

install.packages("tidyquant")
install.packages("ggTimeSeries")
install.packages("ggfortify"")
library(tidyquant)
library(ggplot2)
library(scales)
library(tidyverse)
library(ggfortify)

df <- PortlandWaterLevel2003
df %>% ggplot(aes(Time, WL)) 
df %>% ggplot(aes(Date, WL)) + geom_line() +   geom_ma(ma_fun=SMA, n=23, size=1, color="red") 
df %>% ggplot(aes(Date, WL)) + geom_line() + geom_ma(ma_fun=SMA, n=23, size=1.5, color="red") + scale_colour_gradient2(
  low = "red",
  mid = "white", # middle color value
  high = "blue",
  midpoint = 0.02, # middle data value
  space= "Lab",
  na.value = "grey50"
) 


timeseries_object_wl <- ts(data=df$WL, start = 1, end = 8040, frequency = 24)
log_wl <-log(df$WL)
plot.ts(log_wl)
plot.ts(df$WL)

timeseries_object_sigma <- ts(data=df$Sigma, start = 1, end = 8040, frequency = 24)
log_sigma <-log(df$Sigma)
plot.ts(log_sigma) 

plot.ts(df$Sigma,  main = "Sigma by Date", xlab = "Date", las=3, ylab = "Sigma")
plot.ts(df$WL,  main = "WL by Date", xlab = "Date", las=3, ylab = "WL")

autoplot(df, ts.colour="red", ts.linetype="dashed")

