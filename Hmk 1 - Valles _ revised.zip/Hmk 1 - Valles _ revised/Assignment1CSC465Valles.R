library("ggplot2")
library("tidyverse")

#James Valles - Assignment 1 - CSC 465

# ***Question 5a ***
ggplot(data=cellPlans, aes(x=Price, y=DataGB, group=Company)) +
  geom_line(aes(color=Company))+
  geom_point(aes(color=Company)) + scale_x_continuous(breaks = scales::pretty_breaks(n = 10)) +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 10)) + ggtitle("Monthly Data Plan Costs per Carrier ") + xlab("Cost (in U.S. dollars)") + ylab("GB per month")
                                                   
# ***Question 5c***
  
ggplot(cellPlans, aes(cellPlans$DataGB, cellPlans$Price)) + geom_bar(aes(fill = cellPlans$DataGB), 
width = 1.0, position = position_dodge(width=0.5), stat="identity")    + ylab("Cost (in U.S. dollars)") + xlab("GB of Data") + 
theme(legend.position="right", legend.title = element_text(color="black", size=9, face="bold"),axis.title.x = element_text(color="black", size=12, face="bold"), 
axis.title.y = element_text(color="black", size=12, face="bold")) +   facet_wrap(~cellPlans$Company) + scale_x_continuous(breaks = scales::pretty_breaks(n = 10)) +
scale_y_continuous(breaks = scales::pretty_breaks(n = 10)) + ggtitle("Available Monthly Data Plans & Costs per Carrier ") + labs(fill = "GB of Data")
